package com.rentamaquina.maquina.app.crudRepository;

import com.rentamaquina.maquina.app.entities.Admin;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author @ROCKS
 */
public interface AdminCrudRepository extends CrudRepository<Admin,Integer> {
    
}
