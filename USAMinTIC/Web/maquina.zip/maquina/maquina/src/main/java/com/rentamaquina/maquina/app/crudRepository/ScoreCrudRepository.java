package com.rentamaquina.maquina.app.crudRepository;

import com.rentamaquina.maquina.app.entities.Score;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author  --------------
 */
public interface ScoreCrudRepository  extends CrudRepository<Score,Integer>{
    
}
